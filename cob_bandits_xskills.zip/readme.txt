==================
Readme CoB Bandits
==================

This mod was originally made for our server "Conquest of Blocks".
Since we change our theme to "tribal", we do not have any use for bandits anymore,
so this mod can now freely be used on any other server. I will not provide any support
for this mod. You are free to add, modify or change stuff and even release it to the public,
as long as you give credit to the original author and our server "Conquest of Blocks".

Thanks. Have fun.
Kai Effelsberg - CoB Admin